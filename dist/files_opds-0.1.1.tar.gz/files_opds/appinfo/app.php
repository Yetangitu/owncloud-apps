<?php

$l = OC_L10N::get('files_opds');

\OCP\App::registerPersonal('files_opds', 'personal');



<?php

$l = OC_L10N::get('files');

\OCP\App::registerPersonal('files_opds', 'personal');



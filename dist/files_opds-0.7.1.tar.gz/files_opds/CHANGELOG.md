## 0.7.1 - 2017-01-09
### Added
 - Modified info.xml, added screenshot

## 0.7.0 - 2017-01-09
### Changed
 - New logo
 - First release to be compatible with Nextcloud

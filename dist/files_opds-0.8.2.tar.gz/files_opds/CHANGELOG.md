## 0.8.2 - 2017-01-19
### Fixed
 - Support login tokens ('app passwords', NC/OC) and 2FA (NC)

## 0.8.1 - 2017-01-14
### Changed
 - more robust preview generator, fallback to mimetype icon when showPreview throws exception

## 0.8.0 - 2017-01-14
### New
 - FictionBook 2 (.fb2) metadata parser
 - FB2 preview provider

## 0.7.2 - 2017-01-09
### Fixed
 - XML error after deleting an epub file from Library
 - [#23](https://github.com/Yetangitu/owncloud-apps/issues/23)

## 0.7.2 - 2017-01-09
### Changed
 - Modified info.xml, now with working screenshot url...

## 0.7.1 - 2017-01-09
### Added
 - Modified info.xml, added screenshot

## 0.7.0 - 2017-01-09
### Changed
 - New logo
 - First release to be compatible with Nextcloud

<?php
//load the required files
OCP\Util::addscript( 'files_reader', 'loader');

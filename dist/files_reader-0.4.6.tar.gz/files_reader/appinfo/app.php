<?php
//load the required files

$l = OC_L10N::get('files_reader');
OCP\Util::addscript( 'files_reader', 'loader');

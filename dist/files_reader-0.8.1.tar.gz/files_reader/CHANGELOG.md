## 0.8.1 - 2017-01-09
### Added
 - Modified info.xml, added screenshots

## 0.8.0 - 2017-01-09
### Added
 - new version 0.2.15 of Futurepress epub.js renderer

### Changed
 - New logo
 - First release to be compatible with Nextcloud

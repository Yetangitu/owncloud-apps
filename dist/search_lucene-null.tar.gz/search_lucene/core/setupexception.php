<?php
namespace OCA\Search_Lucene\Core;

class SetUpException extends \Exception {}
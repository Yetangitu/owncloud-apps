owncloud-searchrecoll (0.0.1)
* First release